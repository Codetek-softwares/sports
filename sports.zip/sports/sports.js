document.addEventListener('DOMContentLoaded', () => {
    const featuredSection = document.getElementById('featured');
    const articles = [
        { title: 'Article Title 1', summary: 'Summary of the article...' },
        { title: 'Article Title 2', summary: 'Summary of the article...' },
    ];
    const videos = [
        { title: 'Video Title 1', description: 'Description of the video...' },
        { title: 'Video Title 2', description: 'Description of the video...' },
    ];
    const events = [
        { title: 'Event Title 1', details: 'Details of the event...' },
        { title: 'Event Title 2', details: 'Details of the event...' },
    ];

    const populateContent = (containerId, items) => {
        const container = document.getElementById(containerId);
        container.innerHTML = items.map(item => `
            <div class="item">
                <h4>${item.title}</h4>
                <p>${item.summary || item.description || item.details}</p>
            </div>
        `).join('');
    };

    populateContent('articles', articles);
    populateContent('videos', videos);
    populateContent('events', events);
});